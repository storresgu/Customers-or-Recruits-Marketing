# Article 25 — Revisión de supuestos y diseño M5 v1.0

**Fecha de fijación:** 6 de octubre de 2026. **Estado:** diseño fijado; ejecución pendiente. Esta versión se define después de observar M4 y antes de generar resultados M5. Es un protocolo interno fechado, no un registro público ni un análisis definido antes del piloto.

## 1. Decisión y alcance

El experimento central conserva la propuesta factorial de la especificación: **16 escenarios, 100 pares independientes por escenario, 1.600 pares y 3.200 trayectorias de rama**. Cada población tiene 2.000 personas y diez distribuidores iniciales; el horizonte es de 120 meses. El shock interrumpe la conversión a distribuidor desde el mes 61.

El estudio completo se divide en tres bloques definidos y registrados por separado:

| Bloque | Diseño fijado | Pares | Ramas |
|---|---|---:|---:|
| Principal | 16 escenarios × 100 pares | 1.600 | 3.200 |
| Robustez | 7 variantes × 4 escenarios de referencia × 100 pares | 2.800 | 5.600 |
| Sensibilidad global | 20 trayectorias Morris × 14 puntos × 5 pares × 2 estructuras | 2.800 | 5.600 |
| **Total del protocolo completo** | Se ejecutará por bloques | **7.200** | **14.400** |

Las 3.200 ramas del bloque principal no incluyen sensibilidad ni robustez. Las variantes comparten semillas con sus controles estructurales; por ello, el total de ramas no es el número de observaciones independientes. El registro contiene 1.700 grupos independientes de semillas: 1.600 del factorial y 100 del muestreo Morris, reutilizados deliberadamente dentro de sus comparaciones.

**Esta entrega no ejecutó ninguna simulación.** Incluye matrices, parámetros, semillas y la muestra de sensibilidad. Las extensiones de código que requieren las variantes siguen pendientes.

## 2. Qué mostró el piloto y cómo cambia la interpretación

M4 completó 40 pares, con 204 pruebas aprobadas y conciliación de estados e ingresos. Cinco pares tuvieron volumen externo de control cero en la ventana tardía; diez tuvieron menos de doce unidades. Una rama con shock llegó a cero distribuidores. En las condiciones de mayor captación, el cociente entre volúmenes medios shock/control fue aproximadamente 0,75; con menor captación, 0,42–0,48. Estas razones de medias no son medianas de razones individuales.

Los ingresos netos incorporan compras propias y gastos. La continuidad de una red y la proporción de participantes con caja positiva deben informarse por separado. El piloto no valida los parámetros frente a organizaciones reales ni establece frecuencias empíricas de pérdidas.

No se cambian parámetros para suavizar pérdidas, eliminar extinciones o obtener un resultado favorable. M4 no se mezcla con las réplicas confirmatorias de M5: cambian el tamaño poblacional, los factores y las semillas.

## 3. Revisión de los supuestos

| Supuesto implementado | Consecuencia para la interpretación | Decisión M5 |
|---|---|---|
| Mercado cerrado; estado inactivo absorbente | Pueden agotarse oportunidades y perderse distribuidores de forma irreversible | Mantener; conclusiones limitadas a 120 meses. No afirmar supervivencia indefinida |
| Red social estática Watts–Strogatz, grado inicial 10 y reconexión 0,10 | El alcance comercial depende de relaciones locales | Mantener en principal; contrastar topología en R1 |
| Selección uniforme de diez raíces elegibles | No supone que los fundadores sean líderes de alta centralidad | Mantener y registrar raíces; sin selección posterior de redes convenientes |
| Venta minorista antes del reclutamiento; una persona no se contacta dos veces por el mismo distribuidor/mes | El primer canal puede consumir oportunidades del segundo | Mantener; alternar aleatoriamente el orden en R4 |
| Cuotas discretas: `floor(10 × recruitment_share)` | 0,25 produce 2 contactos; 0,75 produce 7, no 2,5 ni 7,5 | Conservar parámetros originales y reportar cuotas efectivas de 20% y 70% |
| Recompra no consume contactos de captación y no tiene límite de atención | Puede favorecer la persistencia de relaciones de compra | Declarar como servicio sin restricción; limitarlo en R6 |
| Reasignación automática si sale el vendedor | Puede amortiguar la pérdida de distribuidores | Eliminarla en R2 |
| Fatiga acumulativa sin recuperación | El tiempo y las exposiciones pueden reducir la captación aun sin shock | Mantener; eliminar la penalización en R5; nunca atribuir toda caída temporal al shock |
| Shock afecta únicamente la conversión de reclutamiento | Persisten intentos, fatiga y gastos de contactos infructuosos | Definirlo como shock de éxito de incorporación con esfuerzo fijo; contrastar reasignación de esfuerzo en R7 |
| Abandono depende de pérdidas recientes | La caja puede reforzar la salida y la pérdida de vendedores | Mantener; retirar la respuesta a pérdidas en R3 |
| Compras propias restan caja, sin valorar utilidad del consumo | Caja negativa no equivale a utilidad personal negativa | Mantener el estimando de caja; no llamarlo bienestar ni rentabilidad económica completa |
| Precio y costos no entran directamente en la probabilidad de compra/incorporación | Variar gastos estudia contabilidad y salida, no elasticidad de demanda ni disuasión directa de entrada | Declarar esta frontera; sensibilidad de costos sin interpretar respuestas de precio no implementadas |
| Solo una comisión de patrocinio; sin cualificación ni compresión | No representa todos los planes multinivel | Mantener el plan mínimo y nombrarlo expresamente |
| No hay inventario, financiación, valoración del trabajo, satisfacción dinámica, referidos ni entrada de población | No permite conclusiones sobre solvencia empresarial o todos los canales de demanda | Mantener fuera de v1.0; documentar como limitaciones |

La cuota de reclutamiento es un presupuesto máximo. Un cupo sin usar no prueba saturación global: puede reflejar elegibilidad, el orden de los canales o su solapamiento. Se guardarán contactos efectivos, cupos, exposiciones y vecinos elegibles.

## 4. Experimento principal

| Factor | Nivel bajo | Nivel alto |
|---|---:|---:|
| Captación minorista `p_retail` | 0,03 | 0,12 |
| Recompra `p_repurchase` | 0,30 | 0,80 |
| Cuota nominal de reclutamiento `recruitment_share` | 0,25 → 2 contactos | 0,75 → 7 contactos |
| Abandono basal `distributor_churn` | 0,01 | 0,05 |

Los cupos minoristas complementarios son ocho y tres. Los niveles de abandono son el componente basal; la probabilidad total puede ser mayor por el componente de pérdidas. Las probabilidades de compra son bases para un agente neutral, no promedios realizados de toda la población.

Se cruzan todos los factores: S01–S16, detallados en `main_matrix.csv`. El resto de parámetros permanece en `main_design.json`, incluida la comisión 0,10, consumo personal 0,30, una unidad de entrada, precios 1,00/0,70 y los costos establecidos. No se cambian simultáneamente supuestos estructurales en el factorial.

Cada par se inicializa una vez, corre hasta el cierre del mes 60 y se bifurca con estado completo. El control mantiene multiplicador 1; el shock pasa a 0. Se conservan claves de azar por evento, sin condición experimental en las claves compartidas. Las ventanas son 49–60, 61–72 y 109–120. No hay reactivación ni venta directa de la empresa si faltan distribuidores.

## 5. Estimandos, incertidumbre y precisión

**Primario:** diferencia pareada del total de unidades externas de los meses 109–120, `delta = shock − control`. Se incluyen todos los pares, también ceros y extinciones. Se reportan medias de cada rama, media de delta, error estándar Monte Carlo y un IC de la media por bootstrap percentil de 20.000 remuestreos de pares completos. La semilla de análisis se deriva por SHA-256 del esquema `article25-m5-analysis-v1`, bloque, escenario, resultado y variante; la serialización, truncamiento y generador se fijan en `analysis_contract.json`. No se utilizan meses como réplicas independientes.

**Secundarios:** respuesta inmediata, suma de distribuidores-mes, diferencia de medias de medianas mensuales netas, compras por categoría, participación del volumen externo, nuevos clientes, recompra, abandono, exposiciones, solapamiento, pérdida de servicio y extinción. Resultados acumulados: mediana y cuantiles netos, proporción de pérdidas y Gini bruto para todos los participantes históricos, con activos al cierre como cohorte separada. Las cohortes de participantes pueden diferir entre ramas por efecto del shock; los contrastes acumulados por cohorte no son efectos sobre una población fija de personas.

La razón de resiliencia exige control positivo. Control cero deja NA con motivo, incluido 0/0; no se imputa uno ni se elimina ese par de la diferencia primaria. Se informa el número de razones válidas y controles con menos de doce unidades. Las razones superiores a uno y `1 − razón` negativo se conservan. Si falta alguna mediana mensual por cohorte vacía, la media de medianas de esa ventana es NA; no se convierte la extinción en ingreso cero. No hay razones de ingresos netos.

**Regla de precisión fijada:** ejecutar exactamente cien pares por escenario del principal. Al cierre, calcular `h = 1,9842169515 × sd(delta)/sqrt(100)` como semiancho diagnóstico t con 99 grados de libertad, y contrastarlo con `0,10 × max(media_control, 12)` unidades. Publicar ambos valores y si se alcanzó la meta. Este diagnóstico de error Monte Carlo no demuestra significancia sustantiva y no se sustituye por un criterio de signo o p-valor.

No hay comprobaciones sucesivas para detener las réplicas cuando aparece un resultado deseado. **Cien pares es el tamaño fijado, no una garantía de cumplir la meta.** Si la precisión resulta insuficiente, conservar y comunicar el resultado y preparar una ampliación versionada antes de nuevas simulaciones. El piloto de N=500 sugiere que las condiciones de bajo volumen pueden exigir más réplicas; no permite calcular de forma fiable las necesidades de las nuevas dieciséis celdas de N=2.000.

Para comparar variantes estructurales, estimar por réplica `delta_variante − delta_baseline`, manteniendo unidas las cuatro ramas en el bootstrap. No tratar las variantes con la misma semilla como independientes. Los contrastes factoriales se obtienen de las dieciséis medias de delta con igual peso por celda; enfatizar captación×recompra y sus interacciones con esfuerzo y abandono. Como metamodelo descriptivo, ajustar efectos principales y las seis interacciones dobles, con incertidumbre por remuestreo estratificado dentro de cada celda. No seleccionar términos por p-valores ni presentar extrapolaciones fuera de los rangos ensayados.

## 6. Robustez: siete contrastes individuales

Se fijan cuatro escenarios de referencia: **S03, S07, S11 y S15**. Cubren las cuatro combinaciones de demanda con cuota nominal de reclutamiento 0,75 y abandono basal 0,01. Son celdas del principal: se reutilizan sus cien pares baseline. Cada variante añade cuatrocientos pares, compartiendo semillas con esos baseline. Su alcance es ese estrato de esfuerzo alto y abandono bajo; no se generaliza automáticamente la robustez a las dieciséis celdas.

| Código | Cambio único | Qué pone a prueba |
|---|---|---|
| R1 | Grafo aleatorio regular de grado 10, N=2.000, sin reintentar para forzar conectividad | Dependencia del patrón local de relaciones; conserva grado medio y número de aristas, aunque también cambia la distribución de grado frente a Watts–Strogatz |
| R2 | Sin reasignación de vendedor durante un episodio de cliente | Si el mantenimiento de ventas requiere reemplazar automáticamente vendedores que salen |
| R3 | `loss_exit_weight = 0` | Si la relación entre pérdidas y abandono explica el efecto |
| R4 | Una moneda equiprobable por mes decide venta→reclutamiento o reclutamiento→venta | Sensibilidad a la prioridad de canales |
| R5 | `fatigue = 0` | Dependencia de la fatiga acumulativa |
| R6 | Máximo diez oportunidades de recompra atendidas por distribuidor operativo y mes | Dependencia de capacidad ilimitada de servicio |
| R7 | Desde el mes 61, shock reasigna los diez cupos a captación y cero a reclutamiento | Respuesta bajo un límite optimista de reasignación inmediata de esfuerzo |

**Detalles operativos obligatorios:**

- R1 usa la semilla de red registrada; personas, atributos y reglas conservan sus claves. Dentro de cada par la red sigue siendo idéntica. Entre topologías no se exige igualdad de aristas ni se interpreta el contraste como efecto puro del clustering.
- R2 conserva el vendedor mientras opere. Tras su salida, el cliente queda sin servicio durante el resto del episodio, con el incremento de abandono habitual. Solo puede conseguir nuevo vendedor tras volver a U y ser adquirido de nuevo. No hay transferencia directa a otro vendedor ni reactivación del antiguo.
- R4 conserva la fase inicial de disponibilidad de vendedores, las fases posteriores de recompra/contabilidad/salida y todas las prohibiciones de cascadas. El orden mensual usa un nuevo identificador de proceso aleatorio estable, común a control y shock. Los nuevos clientes no se reclutan ese mes y los nuevos distribuidores no operan ese mes, cualquiera que sea el orden.
- R6 aplica el límite a clientes iniciales que siguen en C después de los contactos. Por vendedor, se ordenan mediante una prioridad aleatoria estable los clientes elegibles; los primeros diez reciben oportunidad, compren o no. El excedente se marca sin servicio y enfrenta el incremento de abandono. No se reasigna por exceso de capacidad. Es un límite adicional de servicio, separado del presupuesto de captación/reclutamiento, que permanece igual.
- R7 conserva los cupos baseline hasta el mes 60 y durante toda la rama control. En shock, desde el 61, la conversión sigue prohibida, no hay intentos de reclutamiento ni sus gastos; hasta diez contactos minoristas son posibles. No modifica el presupuesto total ni representa una teoría de aprendizaje. Se analiza como **política alternativa conjunta**, no como la misma intervención aislada del principal.

R1–R3 cubren las tres pruebas estructurales prioritarias de la especificación; R4–R7 responden a supuestos especialmente sensibles para esta pregunta. No se cruzan entre sí. Tamaños alternativos, extensión a 240 meses, reactivación, heterogeneidad homogénea y otros planes de comisión quedan fuera de esta versión. No sostener conclusiones que necesiten esas comprobaciones sin ampliar previamente el protocolo.

## 7. Sensibilidad global fijada

Se amplía de los aproximadamente 10–12 factores inicialmente propuestos a **trece**, para conservar conversión, esfuerzo, abandono, fatiga, consumo, comisión y los tres componentes de gastos. Todos los rangos son exploratorios; no son distribuciones empíricas.

| Parámetro | Mínimo | Máximo |
|---|---:|---:|
| Captación minorista | 0,01 | 0,20 |
| Recompra | 0,10 | 0,90 |
| Incorporación por contacto | 0,005 | 0,10 |
| Cuota nominal de reclutamiento | 0,10 | 0,90 |
| Abandono de cliente | 0,01 | 0,10 |
| Abandono basal de distribuidor | 0,01 | 0,10 |
| Peso de pérdidas en abandono | 0 | 0,10 |
| Fatiga | 0 | 0,30 |
| Consumo personal | 0 | 0,60 |
| Comisión | 0 | 0,20 |
| Gasto fijo mensual | 0 | 0,15 |
| Costo por contacto | 0 | 0,02 |
| Cuota de entrada | 0 | 0,50 |

Morris elemental, veinte trayectorias aleatorias no optimizadas, seis niveles por variable y paso normalizado 0,6. Cada trayectoria visita catorce puntos cambiando un solo parámetro por paso. Cinco semillas por punto, comunes a los catorce puntos de una trayectoria y a ambas estructuras. Las trayectorias tienen grupos de semillas independientes. Se repite toda la muestra en baseline B0 y en R2 sin reasignación: **280 puntos × 5 pares × 2 estructuras = 2.800 pares**. N=2.000 y los demás parámetros permanecen en baseline, fuera de los trece factores muestreados.

La muestra se archiva antes de ejecutar: `morris_sample.csv` y `morris_moves.csv`. El generador propio es transparente y valida la geometría; no se afirma que sea una muestra optimizada de SALib. El método de efectos elementales y los resúmenes μ, μ* y σ están documentados en las fuentes metodológicas indicadas al final.

Calcular efectos elementales sobre el promedio de las cinco réplicas por punto, dividiendo cada cambio por el paso normalizado con su signo. Reportar μ, μ*, σ e intervalos jerárquicos de 2.000 remuestreos: trayectorias completas y, dentro de ellas, semillas conservadas conjuntamente en puntos/estructuras. La variabilidad σ puede incluir ruido estocástico residual; no es una medida pura de interacción. Los rangos se comparan dentro de cada resultado, no entre unidades diferentes.

Priorizar diferencias de volumen externo, volúmenes de cada rama e ingresos netos acumulados de la cohorte histórica. Para razones, Gini, cuotas o tasas indefinidas: analizar primero el indicador de ausencia; calcular efectos condicionales solo sobre trayectorias completas, informar cuántas quedan y no presentar un ranking con menos de diez. No sustituir ausencias por cero. La discretización de los cupos debe aparecer en la muestra y en la interpretación de la sensibilidad de esfuerzo.

Un estudio Sobol/eFAST no está incluido ni prometido por esta versión. Tras el screening, seleccionar parámetros y fijar un protocolo adicional solo si su costo y precisión son defendibles; Morris no estima índices de Sobol ni proporciones de varianza.

## 8. Regímenes secundarios e interpretación

Los resultados continuos y sus denominadores siguen siendo principales. Se añade una clasificación descriptiva por par, sin puntaje ponderado único y sin categorías legales:

1. Marcar extinción de cada rama según D=0 al mes 120 y bajo volumen si control tardío <12 unidades. Control cero hace indefinida la razón. Los casos de bajo volumen quedan **sin clasificación de resiliencia**, aunque se conserven para el efecto primario.
2. Entre controles ≥12: razón shock/control ≥0,80 indica retención alta; [0,50,0,80) retención intermedia; <0,50 retención baja. Se conservan razones >1.
3. Identificar composición mayoritariamente externa si `external_units/total_units ≥0,50` por rama y ventana; total cero implica NA. La composición no determina la viabilidad de los participantes.
4. Presentar mediana neta acumulada histórica, signo respecto de cero y proporción con pérdidas como eje independiente. Los activos al cierre permanecen separados.
5. Usar etiquetas compuestas únicamente si sus condiciones son transparentes: demanda externa persistente bajo shock requiere al menos doce unidades externas tardías en shock, distribuidores activos en toda la ventana tardía y composición externa mayoritaria. La retención alta/intermedia/baja se añade a esa descripción. No llamar «colapso por saturación» a una extinción sin evidencia del mecanismo.

Los umbrales son convenciones analíticas definidas después del piloto, no límites universales. Recalcular la clasificación con cortes de volumen {6,12,24}, composición {0,40;0,50;0,60}, retención alta {0,70;0,80;0,90} y baja {0,40;0,50;0,60}: **81 combinaciones**, sin nuevas simulaciones. Informar cambios de clasificación y mantener los casos ambiguos.

## 9. Implementación y orden de ejecución

Antes de correr M5 se necesita una versión de producción identificada con huella de código y entorno, cuyo baseline reproduzca M3. Actualmente solo están implementadas directamente R3 y R5 mediante parámetros existentes; R1, R2, R4, R6 y R7 necesitan extensiones, validación de configuración y pruebas de sus reglas.

El ejecutor de producción debe leer el plan y conservar sus semillas; nunca escoger nuevas semillas para reemplazar un resultado incómodo. Los identificadores del plan son identificadores de trabajo; si el motor genera otros identificadores de salida, guardar una correspondencia uno a uno, sin perder el identificador del plan. `main_design.json` es válido para el esquema M3, pero no es el archivo de ejecución de las variantes ni del Morris.

Orden fijado: implementar extensiones y pruebas; comprobar que el baseline conserva los resultados M3; probar exportación compacta frente a trazas completas; medir N=2.000; ejecutar principal; ejecutar variantes; ejecutar screening; analizar y redactar ODD/resultados. Para el benchmark se usan las réplicas 1–2 de S01 y S16. Si cumplen todas las verificaciones con la versión final congelada, cuentan dentro de las cien previstas; no se añaden al tamaño científico. Los fallos técnicos se conservan y se repite la misma semilla después de corregir y versionar el código.

Para todos los pares: guardar configuración, semillas, entorno, identificadores, estados necesarios para reconstrucción/reinicio en 0/60/120, métricas mensuales, resultados por participante y conciliaciones de caja/volumen. Exportar agregados de transacciones/eventos para producción. Trazas completas preseleccionadas: réplicas 1–2 de cada celda principal y de cada variante/escenario; en Morris, trayectoria 1, todos sus puntos, réplica 1, ambas estructuras. Total: 116 pares con trazas completas; conservar también las trazas de todo fallo. Estas selecciones no dependen de los resultados.

La producción compacta debe dar exactamente las mismas métricas y estados que la salida completa. No eliminar contadores, historias financieras o información necesaria para continuar el modelo. M4 produjo 1,73 GiB brutos con solo cuarenta pares y N=500; esa evidencia justifica cambiar el modo de salida antes de ampliar. No se promete una duración de M5 mediante extrapolación lineal del piloto.

## 10. Fuentes y archivos congelados

Fuentes internas: guía del estudiante adjunta; especificación mínima v0.1; implementación M3; informe y tablas M4. Se retiene la huella de código de referencia:

`c877a6d87a39aed484d8e4b2cc896845bbf42dbd7a821620157b5ad429935766`

Fuentes metodológicas consultadas el 6 de octubre de 2026: [muestreo Morris en SALib](https://salib.readthedocs.io/en/stable/api/SALib.sample.morris.html) y [análisis Morris en SALib](https://salib.readthedocs.io/en/stable/api/SALib.analyze.html). Se usan para fundamentar el método, no para justificar como empíricos los niveles o tamaños elegidos.

El paquete contiene el protocolo, matriz factorial, diseño principal, variantes, muestra Morris, movimientos elementales, plan de 14.400 ramas, generador, validación y huellas SHA-256. **Las matrices y semillas están fijadas; el código nuevo y los resultados M5 todavía no existen.** Toda modificación sustantiva deberá generar una versión posterior del protocolo antes de las ejecuciones afectadas.
