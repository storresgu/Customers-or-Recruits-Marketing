# Article 25 — Adenda de implementación M5 v1.1

Fecha: 6 de octubre de 2026. Se fija antes del benchmark M5. Complementa el protocolo v1.0; conserva escenarios, rangos, matrices, IDs y semillas, 7.200 pares previstos y selección de 116 pares con trazas completas.

## Precisión del generador R1

R1 utiliza `networkx.random_regular_graph` de NetworkX 3.7, grado 10 y N=2.000, con la clave NETWORK del modelo. No se vuelve a generar una red para imponer conectividad. La expresión `uniform_random_regular` del JSON v1.0 se sustituye por `networkx_random_regular`: la documentación describe uniformidad asintótica bajo condiciones sobre grado y tamaño; no se garantiza uniformidad exacta de la muestra finita. No se ha ejecutado R1 científico antes de fijar esta precisión. El contraste se interpreta como cambio de generador y estructura, no como efecto aislado del clustering.

Fuente primaria: https://networkx.org/documentation/stable/reference/generated/networkx.generators.random_graphs.random_regular_graph.html (consultada 2026-10-06).

## Contratos de implementación

- R1: `social_topology="random_regular"`.
- R2: `seller_reassignment=False`; el cliente permanece sin vendedor hasta acabar su episodio.
- R3: `loss_exit_weight=0`.
- R4: `channel_order="random_monthly"`; clave `m5_channel_order`, moneda mensual compartida por ramas.
- R5: `fatigue=0`.
- R6: `repeat_service_capacity=10`; clave `m5_repeat_priority`; el cupo corresponde a oportunidades, no a compras exitosas.
- R7: `shock_reallocate_contacts=True`; únicamente cuando mes >=61 y multiplicador de reclutamiento=0 se usan 10 cupos minoristas y 0 de reclutamiento.

Los nuevos campos tienen valores baseline que preservan M3. El modo compacto elimina las listas acumuladas de eventos y transacciones, pero conserva ingresos por participante/mes, estados completos, métricas y agregados mensuales de auditoría. Las transacciones siguen generándose y conciliándose dentro de cada mes. Se verifican reinicios desde los checkpoints.

Los archivos están comprimidos sin timestamp para permitir reproducibilidad de bytes. Cada par conserva su ID del plan. El ejecutor puede reutilizar pares completados solo con el mismo código, diseño, semillas y huellas de archivos verificadas. En fallos de una fase mensual se conserva el último checkpoint válido y la traza del mes intentado; no se sustituye la semilla.

Esta versión implementa y verifica el motor y mide cuatro pares preseleccionados del principal. No convierte cuatro pares en evidencia suficiente para inferencia ni modifica tamaños a partir de sus resultados. El análisis inferencial completo permanece pendiente de las corridas previstas.
