# Article 25 — M5: implementación, verificación y benchmark v0.5

Fecha: 6 de octubre de 2026. Versión del motor: **0.5.0-m5**. Protocolo científico v1.0, complementado por adenda de implementación v1.1.

## Resultado

Se implementaron las cinco extensiones pendientes (R1, R2, R4, R6 y R7), se conservaron las dos variantes configurables existentes (R3 y R5), se agregó salida compacta con checkpoints comprimidos y se ejecutaron satisfactoriamente los cuatro pares del benchmark previsto.

**Estado científico:** 4 de 1.600 pares del principal completados, equivalentes a ocho ramas. Faltan 1.596 pares principales, 2.800 de robustez y 2.800 de sensibilidad. Las simulaciones pequeñas de pruebas y paridad no cuentan como réplicas M5. No se ejecutó inferencia final ni se seleccionaron condiciones según los resultados observados.

## Implementación

| Variante | Regla verificada |
|---|---|
| R1 | Grafo regular aleatorio con grado diez; sin selección por conectividad |
| R2 | Un cliente cuyo vendedor sale queda sin servicio hasta terminar su episodio |
| R3 | Eliminar respuesta del abandono a pérdidas mediante peso cero |
| R4 | Prioridad mensual aleatoria de canales, compartida por control y shock; sin cascadas |
| R5 | Eliminar fatiga mediante parámetro cero |
| R6 | Diez oportunidades de recompra por vendedor, con selección aleatoria estable y abandono adicional de no atendidos |
| R7 | En shock desde el mes 61: diez cupos minoristas y cero de reclutamiento; gastos según contactos reales |

La adenda precisa que R1 usa `networkx.random_regular_graph` 3.7. La uniformidad descrita por su documentación es asintótica bajo condiciones, no una garantía de muestreo exactamente uniforme para una red finita. Se aclaró antes de ejecutar R1 científico. Fuentes: [documentación oficial de NetworkX](https://networkx.org/documentation/stable/reference/generated/networkx.generators.random_graphs.random_regular_graph.html).

Las matrices factorial y Morris, los movimientos elementales, el plan y las semillas permanecen byte a byte iguales a la versión fijada. Se resolvieron las 7.200 configuraciones pareadas y la selección de 116 pares con trazas completas. La precisión del generador R1 se registra en la adenda y metadatos del diseño de ejecución.

## Verificación

- **232 pruebas aprobadas:** las 204 existentes y 28 nuevas; tiempo del último conjunto: 7,92 segundos.
- Paridad entre procesos independientes M3 y M5: tres pares, 120 meses, semillas 17, 71 y 93; igualdad exacta de agentes, redes, historia mensual, eventos, transacciones e ingresos. Se excluyen únicamente versión y nuevos campos de configuración baseline de la comparación física. El código M3 original se conserva como referencia.
- En las ocho configuraciones B0/R1–R7 se comprobaron estados, métricas, ingresos y agregados iguales entre salida completa y compacta; reinicio desde checkpoint y prueba de intervención nula.
- Pruebas específicas de cupos, capacidad por oportunidad aunque no haya compra, clientes reclutados fuera de la cola de recompra, continuidad del episodio sin vendedor y restricciones de cascadas.
- Reutilización de un par sin volver a simularlo y rechazo de archivos modificados. En fallo inyectado, el modelo conserva estado anterior y traza del mes fallido incluso en modo compacto.
- Benchmark: 960 filas mensuales, conservación de N=2.000, prefijo común hasta 60 y cero reclutamientos postshock. Máximo error mensual de conciliación de caja: **3.55e-15**.
- Se verificaron por SHA-256 los cuarenta archivos incluidos en los manifiestos de los cuatro pares, además de comprobar lectura de checkpoints.

## Benchmark medido

S01 y S16, réplicas 1 y 2, según el protocolo. Todas las ramas llegaron al mes 120. Se retuvieron trazas completas porque esos pares forman parte de la muestra de auditoría preseleccionada.

| Par | Semilla | Simulación (s) | Exportación (s) | Archivos del par (MiB) |
|---|---:|---:|---:|---:|
| main__B0__S01__r001 | 3984742805 | 15.12 | 2.86 | 0.84 |
| main__B0__S01__r002 | 916855803 | 16.07 | 2.92 | 0.82 |
| main__B0__S16__r001 | 2521234058 | 18.95 | 8.63 | 3.33 |
| main__B0__S16__r002 | 1577098319 | 19.74 | 10.47 | 3.65 |

Tiempo total del ejecutor: **100.53 segundos**. Incluye inicialización, bifurcación, validación y exportación. La simulación de cada par comparte los primeros sesenta meses; no representa dos corridas independientes de 120 meses. Tamaño total de resultados: **8.65 MiB**, antes de empaquetar el ZIP.

Para los ocho checkpoints finales, serializar exactamente los mismos estados y métricas en modo compacto reduce los bytes comprimidos de 6,418,777 a 1,156,467, una reducción de **82.0%**. Esta medición corresponde a checkpoints finales, no a toda la carpeta ni a una aceleración de cómputo. El modo compacto conserva los ingresos por participante/mes y la información para continuar la dinámica.

Los tiempos observados son 15,12–19,74 segundos de simulación por par. Como referencia de escala, multiplicar ese intervalo por los 1.596 pares restantes da aproximadamente 6,7–8,8 horas de simulación secuencial, **más exportación y verificación**. No es una predicción validada: solo se midieron dos celdas, los demás escenarios pueden generar actividad distinta y las variantes/Morris requieren su propia medición. No extrapolar estos cuatro pares al costo del protocolo completo.

## Reproducción y siguiente ejecución

Código congelado:

`2b93a07ef7665068c70045353f98c41646fda9211889fc635f656e32c793bec4`

Entorno: Python 3.12.14, NumPy 2.3.5, NetworkX 3.7. El paquete incluye dependencias exactas, pruebas, comparación contra M3, diseño de ejecución, contrato analítico, adenda y comprobantes de verificación.

El ZIP de resultados incluye los estados iniciales, checkpoints de prefijo y finales, métricas, participantes, efectos pareados y manifiestos de los cuatro pares. Para completar el principal, usar el ejecutor `article25.production` con selección `main` y `--reuse` apuntando al benchmark descomprimido. El README contiene los comandos completos. Ese mecanismo comprueba identidad de código y diseño y evita volver a contar los cuatro pares.

La ejecución es secuencial. Un proceso interrumpido de forma abrupta necesita conciliar su manifiesto antes de reanudar; no se promete continuación automática después de una interrupción del entorno. Los resultados existentes nunca se sobrescriben.

**Siguiente paso:** completar los 1.596 pares pendientes del principal con este código, conservar las cien réplicas por celda y después continuar robustez y sensibilidad. El módulo de inferencia final (bootstrap, resumen Morris, clasificaciones y metamodelo) aún debe implementarse siguiendo el contrato ya fijado. No hay simulaciones en segundo plano al cerrar esta entrega.
