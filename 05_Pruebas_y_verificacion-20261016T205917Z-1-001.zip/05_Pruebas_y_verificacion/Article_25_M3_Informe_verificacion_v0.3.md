# Article 25 — Informe de implementación y verificación de M3

**Versión del modelo:** 0.3.0-m3. **Especificación:** 0.1. **Fecha:** 27 de septiembre de 2026 (UTC).

M3 está implementado y verificado. La suite completa tiene **204 pruebas aprobadas**, sin fallos, errores ni omisiones: 139 pruebas conservadas de M1/M2 y 65 nuevas de M3. Se ejecutó un par técnico control–shock de 120 meses y 500 personas. El piloto de investigación quedó preparado con 40 pares —80 trayectorias de rama— y **no se ejecutó**.

## 1. Alcance implementado

- Ejecutor de experimentos definidos mediante JSON, con escenarios, réplicas, ventanas y multiplicador del shock explícitos.
- Un estado inicial y una historia común hasta el cierre del mes 60; dos copias completas para continuar control y shock hasta el mes 120.
- Control con multiplicador de reclutamiento 1 y shock principal con multiplicador 0 desde el inicio del mes 61. La única diferencia configurada entre ramas es ese multiplicador.
- Registro reproducible de semillas, identificadores de experimento/escenario/réplica/par/rama, parámetros completos, versiones, huellas de configuración y código, entorno, tiempos y estado de ejecución.
- Totales por ventana, diferencias pareadas, razones de resiliencia válidas y motivos explícitos de valores indefinidos.
- Distribuciones de ingresos netos acumulados para todos los participantes históricos, conservando a quienes abandonaron, y resumen separado de quienes siguen activos.
- Cuantiles, rango intercuartílico, proporción con pérdidas e ingresos positivos; Gini de ingresos brutos acumulados no negativos.
- Exportación de estados, checkpoints, métricas mensuales, resultados por participante, libros de transacciones, ingresos y eventos.
- Preparación del piloto mediante `--prepare-only`, sin inicializar ni ejecutar simulaciones.

M2 ya contenía la contabilidad necesaria para su regla de abandono asociada a pérdidas. M3 reutiliza las reglas verificadas de margen minorista, comisión de un nivel, compras propias, gastos y cuotas. No introduce cambios en las ecuaciones comerciales ni ajustes numéricos destinados a producir un resultado particular.

## 2. Verificación realizada

| Comprobación | Evidencia |
|---|---|
| Regresión completa M1/M2 | Las 139 pruebas anteriores siguen aprobadas |
| Suite completa | 204 aprobadas; 0 fallos, 0 errores, 0 omitidas; 5,890 s en este entorno |
| Dos controles | Estados e historias completas idénticos; diferencias pareadas iguales a cero cuando están definidas |
| Historia anterior al shock | Coincidencia exacta de métricas, eventos, transacciones e ingresos hasta el mes 60 |
| Interrupción completa | Cero incorporaciones desde el mes 61 en la rama shock |
| Checkpoints | Exportación, lectura y continuación reproducibles; copias independientes entre ramas |
| Identificación y semillas | Identidades únicas, semillas compartidas dentro de cada par y distintas entre pares; independencia del orden de escenarios |
| Límites numéricos | Cohortes vacías, denominadores cero, ingresos negativos, Gini vacío/cero y cuantiles verificados con ejemplos calculables |
| Salidas y protección | Identificadores y huellas presentes; lectura de archivos exportados; rechazo de directorios existentes |
| Reproducibilidad entre procesos | Registros científicos idénticos con distintos valores de `PYTHONHASHSEED` |
| Preparación del piloto | 40 pares / 80 ramas registradas y 0 pares ejecutados |

La primera ejecución de la suite detectó que `1` y `1.0`, aunque equivalentes en la dinámica, podían generar huellas serializadas distintas en una intervención nula. Se normalizó la representación en el registro y se conservó exactamente el campo del control al clonar una intervención nula. La suite completa posterior aprobó las 204 pruebas.

### Comparación con el archivo real de M2

Se recuperó el paquete M2 previo y se cargó su checkpoint de control. Una ejecución nueva con M3, **N = 2.000**, semilla **20260925** y **120 meses**, coincidió exactamente con:

- los 120 registros mensuales;
- los 47.391 eventos;
- las 5.296 transacciones;
- los 3.958 registros de ingresos;
- el estado final de toda la población.

Huella del estado final compartido:

`dc0ab5d9d014be49fe4327aa0d0284b083c49b2015b2956f0fdbe8d6b38e99be`

El resultado está en `verification/m2_regression.json`. La comparación tardó aproximadamente 10,90 s. La compatibilidad de importación es explícita para snapshots/checkpoints M2; M1 sigue admitido únicamente para poblaciones del mes cero. Las nuevas exportaciones llevan la versión M3.

## 3. Par técnico de referencia

**Experimento:** `article25_m3_verification_v01`. **Escenario:** `baseline_n500`. **Réplica:** 1. **Semilla:** 1065052341. **Población:** 500. **Distribuidores iniciales:** 10. **Horizonte:** 120 meses. **Inicio del shock:** mes 61.

La exportación contiene 240 filas mensuales, 164 filas de participantes —91 en control y 73 en shock—, dos resúmenes de rama y nueve efectos pareados: tres ventanas por tres resultados. El tiempo total del ejecutor, incluyendo exportación y comprobaciones, fue aproximadamente **11,17 s** en este entorno. Ese tiempo no es una garantía para otras máquinas ni una estimación definitiva del piloto.

| Ventana | Unidades externas: control | Unidades externas: shock | Diferencia shock − control | Razón shock/control |
|---|---:|---:|---:|---:|
| Previa, meses 49–60 | 351 | 351 | 0 | 1,000000 |
| Inmediata, meses 61–72 | 323 | 322 | −1 | 0,996904 |
| Tardía, meses 109–120 | 121 | 112 | −9 | 0,925620 |

En los meses 61–120 hubo 18 nuevas incorporaciones en control y ninguna en shock. Al mes 120 quedaron 10 distribuidores en control y 7 en shock. Estas cifras documentan **una prueba técnica**, no una estimación del efecto promedio ni evidencia para las conclusiones del artículo.

| Resultado acumulado al mes 120 | Control | Shock |
|---|---:|---:|
| Participantes históricos incluidos | 91 | 73 |
| Mediana neta acumulada, todos los históricos | −2,000 | −1,805 |
| Proporción con pérdida neta, todos los históricos | 0,714286 | 0,671233 |
| Gini bruto acumulado, todos los históricos | 0,686910 | 0,669037 |
| Participantes activos al cierre | 10 | 7 |

Los ingresos están expresados en las unidades monetarias normalizadas del modelo. No son estimaciones empíricas de ingresos de una empresa real.

## 4. Definiciones que quedan fijadas

**Volumen externo:** la diferencia principal es la suma del shock menos la suma del control dentro de cada ventana. La resiliencia requiere denominador de control positivo. Tanto 0/0 como un numerador positivo sobre control cero producen un valor indefinido con motivo. Se conservan las razones mayores que uno y los valores negativos de `1 − resiliencia`. Un control con menos de 12 unidades externas se marca como volumen bajo.

**Distribuidores:** la razón usa la suma de existencias D al cierre de cada mes, expresada en distribuidores-mes. No se confunde con nuevas incorporaciones ni con el número de personas distintas.

**Ingreso neto por ventana:** se calcula la media de las medianas mensuales de la cohorte de ingresos. Si algún mes tiene cohorte vacía, el valor de la ventana es indefinido y se informa cuántos meses fueron válidos. El efecto es una diferencia, nunca una razón. Este estimando es distinto del ingreso neto acumulado por persona.

**Participantes:** la cohorte mensual incluye quienes operaban al inicio y quienes ingresaron durante el mes, incluidos quienes salen al cierre. Los resultados acumulados incluyen todos los participantes históricos. Los activos al cierre se presentan por separado. Los activos tienen duración censurada a la derecha; no se ajustó un modelo de supervivencia.

**Desigualdad e incertidumbre:** el Gini convencional se limita a ingresos brutos acumulados no negativos. El neto conserva su signo. Los resúmenes entre réplicas usan pares independientes; los meses no aumentan el número de réplicas. Los percentiles describen la distribución de simulaciones y se distinguen del error estándar de una media. Con un solo par no se informa error estándar de la media.

**Valores faltantes:** `null` en JSON y celda vacía en CSV, acompañados de motivos y denominadores cuando corresponda.

## 5. Reproducción

Desde el directorio extraído `article25_m3`, usando un entorno Python:

```bash
python -m pip install -r requirements.lock.txt
python -m pip install -e . --no-build-isolation --no-deps
python -m pytest -q
python -m article25.experiments --config configs/verification_m3.json --output outputs/m3_verification
```

El último comando requiere un directorio de salida nuevo. Regenera el par técnico completo. Las huellas de estados y registros científicos deben coincidir con el entorno fijado; tiempos de ejecución y metadatos de plataforma pueden variar.

Entorno probado: **CPython 3.12.14, NumPy 2.3.5, NetworkX 3.7, pytest 9.1.1**. El archivo `requirements.lock.txt` conserva las versiones de las dependencias usadas.

Huella del código fuente del modelo:

`c877a6d87a39aed484d8e4b2cc896845bbf42dbd7a821620157b5ad429935766`

## 6. Entregables y siguiente paso

- `Article_25_M3_Python_v0.3.zip`: código, pruebas, configuraciones, decisiones, informe y evidencias completas de verificación.
- `Article_25_M3_Informe_verificacion_v0.3.md`: este informe.
- `Article_25_M4_Piloto_diseno_v0.1.json`: diseño listo para M4.
- `Article_25_M4_Piloto_semillas_v0.1.csv`: registro de las 80 ramas previstas.
- `Article_25_M3_Par_verificacion_v0.3.zip`: copia separada de las salidas brutas y resúmenes del par técnico.

El siguiente paso es **M4: ejecutar y evaluar el piloto**, con cuatro combinaciones de demanda, diez pares por combinación y el resto de parámetros en baseline. El registro preparado no equivale a una ejecución. La revisión del piloto deberá documentar tiempo, extinción, saturación, denominadores cero y cualquier defecto antes de congelar el diseño principal.

Comando previsto para M4:

```bash
python -m article25.experiments --config configs/pilot_m3.json --output outputs/pilot_v01
```

No se ejecutaron los experimentos principales, sensibilidad ni robustez. No se fijaron umbrales de clasificación de regímenes. La verificación acredita coherencia con las reglas especificadas; la revisión de límites por los supervisores y las etapas posteriores del estudio siguen pendientes. El mercado finito y el estado inactivo absorbente limitan cualquier interpretación de persistencia indefinida.
