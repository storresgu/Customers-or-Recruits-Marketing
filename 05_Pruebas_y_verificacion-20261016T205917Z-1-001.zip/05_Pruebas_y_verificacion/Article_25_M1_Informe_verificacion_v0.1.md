# Article 25 — M1 Python verification report v0.1

**Date:** 25 September 2026 (America/Bogota).  
**Model version:** 0.1.0-m1.  
**Source specification:** Article_25_Especificacion_minima_v0.1.md.  
**Outcome:** M1 implemented and verified. Ready to support M2 implementation.

## 1. Implemented scope

The package implements strict configuration validation, the four-state agent
contract, the initial population, a finite Watts–Strogatz social network,
independent initial sponsor roots, event-keyed randomness, independent state
cloning, JSON snapshots, CSV exports, and a command-line initialization tool.

All parameters from the specification are stored in configuration. Behavioral
and financial parameters are reserved for M2/M3; their presence in a file does
not mean their mechanisms have been implemented. M1 intentionally has no monthly
simulation scheduler.

## 2. Automated verification

Executed from the package directory:

    python -m pytest -q --junitxml=verification/pytest_results.xml

**95 passed; 0 failed; 0 errors; 0 skipped.** The recorded test-suite duration
was 2.109 seconds in this environment. Some tests
are parameterized boundary and transition cases; this is not a count of research
simulation replications.

| Test module | Test cases | Outcome |
|---|---:|---|
| test_config | 30 | Passed |
| test_exports | 9 | Passed |
| test_population | 20 | Passed |
| test_randomness | 10 | Passed |
| test_state_contracts | 26 | Passed |

The tests cover:

- Invalid parameters, unknown and duplicate configuration keys, bounded values,
  and preservation of configuration identity.
- Exact population conservation, unique IDs, initial commercial states, finite
  social edges, and nonisolated initial distributors.
- No initial customers or commercial cash flows; distributor operation starts
  in month 1.
- Separate social and sponsor graphs; one sponsor per nonroot participant,
  acyclic ancestry, metadata consistency, and preservation of historical links.
- Every permitted and prohibited state-transition pair, including the absorbing
  inactive state and separation of customer and participant metadata.
- Beta attribute bounds and broad moment diagnostics, the homogeneous-agent
  variant, and independence from initial commercial role assignment.
- Identical seeds and independent processes reproducing the same state;
  different seeds producing different realizations.
- Event-keyed variates unaffected by intervening draws, ordering, or Python
  hash randomization; filtered candidate sets preserving relative priorities.
- Independent clone histories and graphs; exact snapshot round trips,
  checksum verification, schema rejection, and overwrite protection.
- Empty initial distributor sets, a fully enrolled population, isolated
  populations, and retention of a deliberately disconnected graph fixture.

Sponsor evolution, customer acquisition states, and exits were constructed as
manual fixtures to check structural contracts. They are not implemented
commercial processes or stochastic trajectories.

## 3. Reference initialization

Executed:

    python -m article25.initialize --config configs/baseline.json --seed 20260925 --output verification/reference_initialization

| Quantity | Observed value |
|---|---:|
| Snapshot month | 0 |
| Population | 2,000 |
| Nonparticipant prospects (U) | 1,990 |
| Retail customers (C) | 0 |
| Initial distributors (D) | 10 |
| Inactive former participants (I) | 0 |
| Social edges | 10,000 |
| Mean social degree | 10.0 |
| Social components | 1 |
| Isolated people | 0 |
| Sponsor nodes | 10 |
| Sponsor edges | 0 |
| Distributors operating at month 0 | 0 |
| Distributors eligible in month 1 | 10 |

Initial root IDs: 223, 420, 548, 755, 870, 1077, 1109, 1113, 1218, 1351.

Zero sponsor edges is correct: the ten initial distributors are independent
roots and nobody has yet been recruited. The reference graph happened to be
connected; the generator does not discard disconnected realizations.

The exported initial_state.json was read back successfully and matched the
original state hash. The included manifest records checksums for every export.

## 4. Reproduction and evidence

The ZIP contains the complete source, tests, full baseline and smaller smoke
configurations, installation instructions, the source specification, decisions,
locked dependency versions, JUnit evidence, and the reference state with its
agent and edge lists. The report is also supplied separately.

| Identifier | Value |
|---|---|
| Python | 3.12.14 |
| NumPy | 2.3.5 |
| NetworkX | 3.7 |
| pytest | 9.1.1 |
| Seed | 20260925 |
| Randomness schema | article25-event-rng-v1 |

**Source code SHA-256:** 226b512299747039b22208e033a8bd809900806254e04a421ca095f6b4842b8c  
**Configuration SHA-256:** 6e2a626630e6770dfd9c0baec3cad6f94e815a61659ba157c2a9a7b17333d284  
**Initial-state payload SHA-256:** e6bc4ea2a7403761b3863b0f2492af7abace5ace5e4101b9089fe4ffc0ee7643

Use README.md for installation and commands. Reproduction is demonstrated in
the recorded environment, including independent processes with different
PYTHONHASHSEED settings. No claim is made about every operating system or every
library version.

## 5. Scope remaining before the pilot

M1 verification does not establish correctness of retail conversion equations,
repurchase, recruitment decisions, commercial contact scheduling, transaction
categories, expenses, commissions, or churn decisions. These mechanisms must
be implemented and tested in M2/M3. Monthly shock-control equivalence before the
shock and zero enrollment after interruption also remain future verification
gates.

No 120-month simulation, 80-trajectory pilot, sensitivity analysis, or substantive
research experiment was executed. This release verifies a computational
foundation; it is not empirical validation or evidence about actual MLM networks.

**Next action:** implement and verify M2, preserving the M1 agent/state and
randomness contracts, then add accounting and matched-shock execution in M3.
