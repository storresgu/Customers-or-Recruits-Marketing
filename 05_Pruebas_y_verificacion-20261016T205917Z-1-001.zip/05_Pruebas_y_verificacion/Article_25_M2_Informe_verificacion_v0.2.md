# Article 25 — M2 Python verification report v0.2

**Date:** 26 September 2026 (America/Bogota).  
**Code version:** 0.2.0-m2.  
**Source specification:** Article_25_Especificacion_minima_v0.1.md.  
**Outcome:** M2 implemented and verified; ready for M3 experiment infrastructure.

## 1. Implemented capabilities

M2 adds fixed retail/recruitment contact budgets, selection without repeated
contacts by the same distributor within a month, finite-neighborhood competition,
channel-specific exposure fatigue, retail acquisition, reacquisition, repurchase,
seller reassignment, recruitment, next-month activation, participant purchasing,
customer churn, loss-responsive distributor exit, and the monthly scheduler.

A complete recruitment interruption sets enrollment success to zero while keeping
opportunity contacts, costs, and the demand rules in place. Stable event keys
retain the M1 random-number contract. Population and product flows are checked
after each month. Steps are atomic: a failure cannot commit a partial month.

## 2. Accounting dependency resolved

The specification places loss-responsive exit in M2 but the financial module in
M3. Net income is required to execute that exit rule. Consequently, M2 includes
the already specified minimum ledger: retail margin, a single paid sponsor level,
participant purchases, entry fees, operating expense, and actual contact costs.
No parameter or compensation equation was changed.

Tests use hand-calculated examples to verify margins, commissions, net cash,
nonpayment to inactive sponsors, preservation of current-month commissions for
participants exiting at month end, and absence of rewards for enrollment alone.
Income histories and cumulative balances reconcile with the exported participant
accounts. Personal-use value and firm profit are not treated as participant cash.

M3 will implement production matched-pair execution, experimental registries,
shock-window indicators, cumulative-cohort and distribution measures, and
experiment-level summaries. This sequencing adjustment does not constitute a
change in the research design.

## 3. Automated verification evidence

Executed from the package directory:

    python -m pytest -q --junitxml=verification/pytest_results.xml

**139 passed; 0 failures; 0 errors; 0 skipped.** Recorded suite duration:
5.170 seconds in the tested environment.
The total includes 95 prior M1 cases and 44 M2 cases. Version-aware export metadata
was updated for M2. Parameterized cases count as separate tests, not simulation
replications.

| Test module | Cases | Status |
|---|---:|---|
| test_config | 30 | Passed |
| test_exports | 9 | Passed |
| test_m2_accounting | 6 | Passed |
| test_m2_dynamics | 26 | Passed |
| test_m2_reproducibility | 12 | Passed |
| test_population | 20 | Passed |
| test_randomness | 10 | Passed |
| test_state_contracts | 26 | Passed |

New verification covers:

- Exact probability endpoints and numerically stable extreme adjustments.
- Prior-exposure fatigue, contact budgets, within-month pair uniqueness, and
  contact overlap between different distributors.
- Acquisition-month restrictions, stochastic nonpurchase without forced exit,
  one repeat purchase per eligible customer, and reacquisition history.
- Enrollment of prior customers without subsequent external repurchase in the
  same month; no immediate recruitment cascades or ordinary entrant exit.
- Missing seller service, seller replacement, entry-versus-personal purchase
  separation, and nonadditive entrant tags.
- Rolling-income exit, zero/base/extreme exit rules, and preservation of exited
  people in the current-month earnings cohort.
- Hand-calculated accounting identities, one-level commissions, single entry fees,
  financial history bounds, and exclusion of participant purchases from external
  retail volume.
- Identical seeded trajectories, complete checkpoints, independent clones,
  independent Python processes, and exact resumed versus uninterrupted execution.
- Short control/interruption comparisons with identical behavior before the shock
  and no new enrollments afterward; opportunity contacts and their costs remain.
- Three different fixed seeds over 120 months in small populations, reconciling
  population stocks, exclusive product categories, and cumulative cash.
- Static social-network preservation, corrupt checkpoint detection, horizon
  restrictions, and rollback on a deliberate accounting failure.

These are verification fixtures and software tests. The short shock test starts
at month 4 to exercise the boundary cheaply; it is not the planned month-61
research experiment.

## 4. Full-horizon technical reference

Executed:

    python -m article25.run --config configs/baseline.json --seed 20260925 --months 120 --output verification/reference_trajectory

This is **one diagnostic control trajectory**, using 2,000 people, 10 initial
distributors, and the baseline configuration. The recruitment multiplier remains
1.0 throughout. Its outputs are included so the student can inspect individual
contacts, role changes, purchases, and accounts.

| Diagnostic item | Observed value |
|---|---:|
| Completed months | 120 |
| Final nonparticipant prospects | 1,812 |
| Final retail customers | 63 |
| Final active-status distributors | 43 |
| Final inactive former participants | 82 |
| Conserved population | 2,000 |
| Enrollments during the trajectory | 115 |
| Historical sponsor edges | 115 |
| External units over 120 months | 3,876 |
| Purchase records | 5,296 |
| Audit events | 47,391 |

These values are conditional outputs of one technical check. They do not establish
retail resilience, recruitment dependence, participant viability, or a general
research finding. No pilot or main experiment has yet been executed.

## 5. Recovery, preservation, and delivery

The trajectory checkpoint was recovered and compared with its original complete
state and traces. Export checksums were verified. An actual month-zero M1 reference
snapshot was imported through the explicit compatibility path with its state hash
unchanged. The original M1 file manifest was checked; no M1 files were altered.

The ZIP contains source, tests, unchanged baseline parameters, smaller smoke
parameters, exact dependency versions, the source specification, M1/M2 decision
notes, JUnit test evidence, this report, and all reference-trajectory outputs.
The report is also supplied separately. Each run's manifest records file hashes.

| Reproduction item | Value |
|---|---|
| Python | 3.12.14 |
| NumPy | 2.3.5 |
| NetworkX | 3.7 |
| pytest | 9.1.1 |
| Reference seed | 20260925 |
| Randomness schema | article25-event-rng-v1 |

**Source code SHA-256:** 23c6fd0d0089cd9a0c0ea71d95dc315d61c7a6c0d667b8e1296978ce8c08bfca  
**Configuration SHA-256:** 6e2a626630e6770dfd9c0baec3cad6f94e815a61659ba157c2a9a7b17333d284  
**Final population payload SHA-256:** dc0ab5d9d014be49fe4327aa0d0284b083c49b2015b2956f0fdbe8d6b38e99be

## 6. Next step and limits

Proceed to M3: formalize matched control/shock runs with a common preshock prefix,
scenario and seed registries, window summaries, paired effects, missing-denominator
handling, participant-cohort summaries, and experiment output checks. Then execute
the proposed pilot after the complete model and design receive methodological review.

The 80-trajectory pilot, main repeated experiment, global sensitivity screening,
structural robustness studies, and scientific interpretation remain pending.
Passing software verification establishes agreement with explicit rules, not
empirical validation of actual MLM organizations.
