# 02_Shock_y_control_pareados

`Article_25_M3_Par_verificacion_v0.3.zip` contains one matched control/shock pair (500 people, 120 months) used to verify the matched-pair mechanics. It supports the verification described in Section 3.6 of the article and is not a source of reported results.
