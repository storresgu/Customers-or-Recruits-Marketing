# 00_Piloto – Pilot (M4)

Design: retail acquisition probability {0.03, 0.12} × repurchase probability {0.30, 0.80}; 10 matched pairs (control and shock branch) per scenario; 500 people; 120 months; shock from month 61.

## What is in this folder

- `Article_25_M4_Resumenes_ligeros_v0.1.zip` – lightweight files for every pair and branch (600 files, about 16 MB unzipped): `config.json`, `manifest.json`, `run_manifest.json`, `summary.json`, `monthly_metrics.csv`, `run_summary.csv`, `participant_summary.csv`, `paired_effects.csv`, `paired_effects.json`.
- `SHA256_trazas_completas.txt` – checksums of the four full-trace archives.

## Full traces (not in this repository)

The full traces are about 197 MB compressed (about 1.9 GB unzipped), so they exceed GitHub's file-size limits. They include event logs, transactions, participant earnings, population snapshots, and checkpoints.

Access: available from the corresponding author on reasonable request (storresgu@unal.edu.co).

Files: `Article_25_M4_Trazas_retail03_repeat30_v0.1.zip`, `..._retail03_repeat80_...`, `..._retail12_repeat30_...`, `..._retail12_repeat80_...`. Check each download against the SHA-256 values above.
