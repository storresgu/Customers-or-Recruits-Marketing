# 01_Escenarios_principales

`Article_25_M5_Benchmark_v0.5.zip` contains the output of four benchmark runs of the M5 pipeline (run folders `main__B0__S01__r001/r002` and `main__B0__S16__r001/r002`).

The article reports only the pilot. These files are not used for any reported result and are not confirmatory M5 results.
