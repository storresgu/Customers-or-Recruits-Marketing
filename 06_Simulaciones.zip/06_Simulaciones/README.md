# 06_Simulaciones – Simulation outputs

Outputs of the agent-based model used in the article *Customers or Recruits? An Entrepreneurial Marketing Perspective on Retail Demand and Recruitment Dependence in an Agent-Based Model*.

| Folder | Content | Used in the article |
|---|---|---|
| `00_Piloto/` | Pilot (M4): 4 scenarios × 10 matched pairs. Lightweight summaries here; full traces archived externally (see its README) | **Yes** – all reported results |
| `01_Escenarios_principales/` | Output of the M5 benchmark runs (4 runs) | No |
| `02_Shock_y_control_pareados/` | M3 matched-pair verification run (500 people, 120 months) | Verification only (Section 3.6) |
| `03_Sensibilidad/`, `04_Robustez/` | Reserved for future work (empty) | No |

All data are synthetic. They contain no personal data and are not empirical findings. Values are in normalized model units.

The code is in `04_Codigo/`, the parameters in `03_Parametros_y_escenarios/`, and the analysis in `07_Analisis/`.
